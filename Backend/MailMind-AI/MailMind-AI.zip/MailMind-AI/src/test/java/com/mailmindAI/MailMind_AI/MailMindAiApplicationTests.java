package com.mailmindAI.MailMind_AI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailMindAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
