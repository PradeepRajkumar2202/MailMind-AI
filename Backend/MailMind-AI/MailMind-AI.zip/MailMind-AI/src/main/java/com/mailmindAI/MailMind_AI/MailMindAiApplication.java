package com.mailmindAI.MailMind_AI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailMindAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailMindAiApplication.class, args);
	}

}
